import * as utils from "utils.js"


/** @param {NS} ns **/
export async function main(ns) {
	while(true)
	{
		utils.analyze(ns);
		await ns.sleep(5000);
	}
}