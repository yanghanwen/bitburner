import * as utils from "utils.js"
  
/** @param {NS} ns **/
export async function main(ns) { 
	var test = [];
	test[1,2]=3;
	ns.alert(test[1,2]);
}