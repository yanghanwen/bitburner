/** @param {NS} ns **/
export async function main(ns) { 
	var server = ns.args[0];//'pserv-1';

	//拷贝文件
	await ns.scp(['b.js','batch1.js','grow.js','hack.js','weaken.js'],'home',server);

	//执行
	var key = ns.getTimeSinceLastAug() + Math.random().toString(); 
	ns.exec('b.js',server,1,'n00dles',key);

	ns.tprintf("在服务器 %s",server);
}