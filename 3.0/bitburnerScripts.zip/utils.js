/** @param {NS} ns **/
export async function main(ns) {

}

/** 
 * @param {NS} ns 
 * 打印购买服务器的价格
 * **/
export function printServerCost(ns)
{
	//最多只能买 2^20 = 1048576 的RAM
	for(var i =0;i<20;++i)
	{
		var ram = Math.pow(2,i);
		var cost = ns.getPurchasedServerCost(ram);
		ns.tprintf("RAM=%s ost=%s",ram,cost);
	}
} 

/** 
 * @param {NS} ns 
 * 递归 scan
 * **/
export function scan(ns)
{
	var host = ns.getHostname();
	var open = [];
	open.push(host);
	var close = [];

	var result = [];
	
	// //忽略自己的服务器
	// var serverList = ns.getPurchasedServers();
	// for(var i in serverList)
	// {
	// 	close.push(serverList[i]);
	// }

	while(open.length>0)
	{
		var node = open.pop();
		if(close.includes(node))
		{
			continue;
		}
		close.push(node);
		
		var neighbor = ns.scan(node);
		for(var i in neighbor)
		{
			var temp = neighbor[i]; 
			open.push(temp);
			result.push(temp);
		}
	} 

	return result;
}

/** 
 * @param {NS} ns  
 * 收益分析
 * **/
export function analyze(ns)
{
	var maxNode = "";
	var maxPow = -1;

	var all = scan(ns);
	for(var i in all)
	{ 
		var target = all[i];
		var onceMoney = ns.hackAnalyze(target); 
		var hackProb = ns.hackAnalyzeChance(target); 
		var hackTime = ns.getHackTime(target);

		//收益权重
		var hackPow = onceMoney * hackProb / hackTime;
		if(hackPow>maxPow)
		{
			maxNode = target;
			maxPow = hackPow;
		}

		/*
		var hackSecPlus = ns.hackAnalyzeSecurity(1);
		var growSecPlus = ns.growthAnalyzeSecurity(1);
		var weakenTime = ns.getWeakenTime(target);
		ns.weakenAnalyze();
		*/
	}

	var powMoney = ns.hackAnalyze(target); 
	var powHackProb = ns.hackAnalyzeChance(target); 
	var powHackTime = ns.getHackTime(target);

	var data  ="maxNode="+maxNode+"\n";
	data +=  "单次获得金钱:"+powMoney*100 +" %;\n";
	data += "概率:"+powHackProb*100+" %;\n";
	data += "用时:"+powHackTime * 0.001 + " 秒;\n";
	
	var server = ns.getServer(target);
	data += "hasAdminRights:"+server.hasAdminRights+";\n";
	data += "baseDifficulty:"+server.baseDifficulty+";\n"; 
	data += "minDifficulty:"+server.minDifficulty+";\n";
	data += "getActionMaxLevel:"+server.getActionMaxLevel+";\n"; 
	data += "hackDifficulty:"+server.hackDifficulty+";\n"; 
	data += "moneyAvailable:"+server.moneyAvailable+";\n";
	//data += "getServerMaxMoney:"+server.getServerMaxMoney+";\n";
	data += "moneyMax:"+server.moneyMax+";\n"; 
	data += "serverGrowth:"+server.serverGrowth+";\n"; 

	if(ns.fileExists('Forulas.exe'))
	{
		data += "growPercent:"+ns.formulas.hacking.growPercent(server,1,ns.getPlayer(),1)+";\n"; 
	}
	data += "\n"; 
	ns.tprint(data); 


	return maxNode;
}